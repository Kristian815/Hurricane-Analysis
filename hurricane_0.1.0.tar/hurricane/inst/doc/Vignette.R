## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(hurricane)

## -----------------------------------------------------------------------------
data("hurdat")
twintydat <- subset(hurdat, startsWith(as.character(date),"2020"))
twintyid <- unique(twintydat$id)
twintyonedat <- subset(hurdat, startsWith(as.character(date),"2021"))
twintyoneid <- unique(twintyonedat$id)
twintytwodat <- subset(hurdat, startsWith(as.character(date),"2022"))
twintytwoid <- unique(twintytwodat$id)
plot_storm_track(data = hurdat, twintyid) 
plot_storm_track(data = hurdat, twintyoneid) 
plot_storm_track(data = hurdat, twintytwoid) 

## -----------------------------------------------------------------------------
katrina <- subset(hurdat, id == 'AL122005')
# Strongest landfall on August 29: maximum wind speed = 110
katrina_26 <- subset(hurdat, id == 'AL122005')[26,]
plot_storm(katrina_26)
plot_storm(katrina)
sandy <- subset(hurdat, id == "AL182012")
# Strongest landfall on October 29: maximum wind speed = 75
sandy_37 <- subset(hurdat, id == "AL182012")[37,]
plot_storm(sandy_37)
plot_storm(sandy)
harvey <- subset(hurdat, id == "AL092017")
# Strongest landfall on August 26: maximum wind speed = 115
harvey_42 <- subset(hurdat, id == "AL092017")[42,]
plot_storm(harvey_42)
plot_storm(harvey)
ian <- subset(hurdat, id == "AL092022")
# Strongest landfall on September 28: maximum wind speed = 140
ian_26 <- subset(hurdat, id == "AL092022")[26,]
plot_storm(ian_26)
plot_storm(ian)

## -----------------------------------------------------------------------------
dat = hurdat
storm_id <- unique(hurdat$id)
storm_name <- c()
maximum_wind_speed <- c()
minimum_pressure <- c()
made_landfall <- c()
Ace_energy <- c()
for(i in 1:length(storm_id)) {
  data = subset(hurdat, id == storm_id[i])
  storm_name = c(storm_name, unique(data$Name))
  maximum_wind_speed = c(maximum_wind_speed, max(data$Maximum_sustained_wind_speed, na.rm = TRUE))
  if(sum(is.na(data$`Minimum Pressure`)) == nrow(data)) {
    minimum_pressure = c(minimum_pressure, NA)
  } else {
    minimum_pressure = c(minimum_pressure, min(data$`Minimum Pressure`, na.rm = TRUE))
  }
  made_landfall = c(made_landfall, storm_made_landfall(dat, storm_id[i]))
  Ace_energy = c(Ace_energy, ACE_calc(dat, storm_id[i]))
}
unique_hurricane = data.frame(storm_id, storm_name, maximum_wind_speed, minimum_pressure,
                              made_landfall, Ace_energy)
unique_hurricane

## -----------------------------------------------------------------------------
# Alex, 2022
r1 <- subset(hurdat, id == "AL212021")
plot_storm(r1)
# Some hurricanes are able to loop over themselves when making landfalls.
# Nicole, 2022
r2 <- subset(hurdat, id == "AL172022")
plot_storm(r2)
# Most hurricanes' strength changes from weak to strong and back to weak.

## -----------------------------------------------------------------------------
year <- c()
for(i in 1:length(storm_id)) {
  data = subset(hurdat, id == storm_id[i])
  year <- c(year, substr(data$date[1], 1, 4))
}
landfall_data <- data.frame(unique_hurricane, year)

landfall_counts <- aggregate(made_landfall ~ year, data = landfall_data, FUN = sum)

model <- glm(made_landfall ~ as.numeric(year), data = landfall_counts, family = poisson)

null_model <- glm(made_landfall ~ 1, data = landfall_counts, family = poisson)
G <- -2 * (logLik(null_model) - logLik(model))
p_value <- pchisq(G, df = 1, lower.tail = FALSE)
summary(model)
cat("p-value =", p_value, "\n")

## -----------------------------------------------------------------------------
energy_data <- subset(landfall_data, Ace_energy != 0)

model <- lm(log(Ace_energy) ~ as.numeric(year) + minimum_pressure , data = energy_data)
summary(model)

