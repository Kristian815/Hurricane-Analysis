#' Atlantic hurricane database
#'
#' A dataset fot Atlantic basin tropical cyclone updated for 2022
#'
#' @format a dataframe with 53972 rows and 23 columns
#' \describe{
#'     \item{id}{identification of the hurricane}
#'     \item{Name}{name of the hurricane}
#'     \item{date}{date of the hurricane}
#'     \item{time}{time of the hurricane corresponding to the synoptic times of
#'      0000, 0600, 1200, and 1800 UTC}
#'     \item{Record identifier}{identify records that correspond to landfalls or
#'      to indicate the reason for inclusion of a record not at the standard synoptic times}
#'     \item{Status of system}{status of the hurricane}
#'     \item{lat}{latitute of the hurricane, in decimal degrees north}
#'     \item{long}{longitute of the hurricane, in decimal degrees east}
#'     \item{Maximum_sustained_wind_speed}{maximum sustained wind speed for the hurricane in knots}
#'     \item{Minimum pressure}{minimum pressure of the hurricane in millibars}
#'     \item{34 kt NE}{34 kt wind radii maximum extent in northeastern quadrant in nautical miles}
#'     \item{34 kt SE}{34 kt wind radii maximum extent in southeastern quadrant in nautical miles}
#'     \item{34 kt SW}{34 kt wind radii maximum extent in southwestern quadrant in nautical miles}
#'     \item{34 kt NW}{34 kt wind radii maximum extent in northwestern quadrant in nautical miles}
#'     \item{50 kt NE}{50 kt wind radii maximum extent in northeastern quadrant in nautical miles}
#'     \item{50 kt SE}{50 kt wind radii maximum extent in southeastern quadrant in nautical miles}
#'     \item{50 kt SW}{50 kt wind radii maximum extent in southwestern quadrant in nautical miles}
#'     \item{50 kt NW}{50 kt wind radii maximum extent in northwestern quadrant in nautical miles}
#'     \item{64 kt NE}{64 kt wind radii maximum extent in northeastern quadrant in nautical miles}
#'     \item{64 kt SE}{64 kt wind radii maximum extent in southeastern quadrant in nautical miles}
#'     \item{64 kt SW}{64 kt wind radii maximum extent in southwestern quadrant in nautical miles}
#'     \item{64 kt NW}{64 kt wind radii maximum extent in northwestern quadrant in nautical miles}
#'     \item{Radius of Maximum Wind}{radius of Maximum wind values in in nautical miles}
#' }
"hurdat"
