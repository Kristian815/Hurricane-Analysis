#' Determining ACE(Accumulated Cyclone Energy) of a given storm
#' Given a data and the unique ID of a hurricane, return the ACE
#' (Accumulated Cyclone Energy) of the hurricane
#' @param data processed data containing hurricane information
#' @param hurricane unique id of the hurricane to be interpolated
#' @return The Accumulated Cyclone Energy of a given hurricane
#' @examples
#' ACE_exp <- ACE_calc(data = hurdat, 'AL112017')
#' print(ACE_exp)
#' @export

ACE_calc <- function(data = dat, hurricane) {
  hurricane_list = subset(data, id == hurricane)
  hurricane_list = subset(hurricane_list, Maximum_sustained_wind_speed >= 35 )

  hurricane_list = hurricane_list[hurricane_list$time %in% c(" 0000", " 0600", " 1200", " 1800"), ]
  ACE <- 10^-4 * sum(hurricane_list$Maximum_sustained_wind_speed^2)
  return(ACE)
}

