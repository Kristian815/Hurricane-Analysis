#' Plot a map of the position and size of a storm
#'
#' Plot a map of the position and size of a given storm indicated by the hurdat data
#' in a row of the best track dataset using the 34, 50, and 64 knot extent variables.
#'
#' @param row a row of the best track dataset for a given storm
#' @return a map of the position and size of a given storm
#' @examples
#' # plot a map indicated by the row for storm AL172022
#' row <- subset(hurdat, id == 'AL172022')[14,]
#' plot_storm(row)
#' @export
plot_storm <- function(row) {
  state_map <- ggplot2::map_data("state")
  lat <- row$lat
  lon <- row$long
  r34 <- row$"34 kt NE"
  r50 <- row$"50 kt NE"
  r64 <- row$"64 kt NE"
  map_plot <- ggplot2::ggplot() +
    ggplot2::geom_polygon(data = state_map, ggplot2::aes(x = long, y = lat, group = group),
                          fill = NA, color = "black", linewidth = 0.5) +
    ggplot2::geom_point(ggplot2::aes(x = lon, y = lat, size = r34/ 111, fill = "R34"),
                        alpha = 0.25, shape = 21, color = "black") +
    ggplot2::geom_point(ggplot2::aes(x = lon, y = lat, size = r50/ 111, fill = "R50"),
                        alpha = 0.25, shape = 21, color = "black") +
    ggplot2::geom_point(ggplot2::aes(x = lon, y = lat, size = r64/ 111, fill = "R64"),
                        alpha = 0.25, shape = 21, color = "black") +
    ggplot2::theme_bw() +
    ggplot2::theme(panel.grid = ggplot2::element_blank(),
                   panel.border = ggplot2::element_blank(),
                   axis.line = ggplot2::element_blank(),
                   axis.text = ggplot2::element_blank(),
                   axis.title = ggplot2::element_blank(),
                   legend.position = "bottom",
                   legend.key = ggplot2::element_blank()) +
    ggplot2::scale_fill_manual(values = c("R34" = "red", "R50" = "orange", "R64" = "yellow"),
                               name = "Wind radius (nautical miles)",
                               guide = ggplot2::guide_legend(reverse = TRUE)) +
    ggplot2::scale_size_continuous(name = "Wind radius (nautical miles)")
  return(map_plot)
}
