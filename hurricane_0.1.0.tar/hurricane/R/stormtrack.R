#' Plot a map of storm tracks
#'
#' Get a map of storm tracks for a selection of storms including country and US state boundaries
#'
#' @param data input data
#' @param hurricane a vector containing different hurricane ids or a string representing the hurricane
#' @return a map with the track of the selected storm(s)
#' @examples
#' # plot storm track for hurricane AL112017
#' plot_storm_track(data = hurdat, 'AL112017')
#' @export
plot_storm_track <- function(data, hurricane) {
  state_map <- ggplot2::map_data("state")
  hurricane_list = hurdat[hurdat$id %in% hurricane,]
  hurricane_list = hurricane_list[, c('id', 'lat', 'long')]
  storm_track <- ggplot2::ggplot() +
    ggplot2::geom_polygon(data = state_map, ggplot2::aes(x = long, y = lat, group = group),
                 fill = NA, color = "black", linewidth = 0.5) +
    ggplot2::geom_path(data = hurricane_list, ggplot2::aes(x = long, y = lat, color = id,
    group = id), alpha = 1) + ggplot2::labs(title = "Storm Track inside US") +
    ggplot2::theme(panel.grid = ggplot2::element_blank(),
          panel.border = ggplot2::element_blank(),
          axis.line = ggplot2::element_blank(),
          axis.text = ggplot2::element_blank(),
          axis.title = ggplot2::element_blank(),
          legend.position = "bottom")
  return(storm_track)
}
