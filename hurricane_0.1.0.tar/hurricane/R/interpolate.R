#' Interpolating a storm track
#'
#' Given a data and the unique ID of a hurricane, return a storm track's latitude,
#' longitude, and maximum sustained wind speed to 30 minute increments
#' @param data processed data containing hurricane information
#' @param hurricane unique id of the hurricane to be interpolated
#' @return a dataframe containing the following components
#' \itemize{
#'   \item \code{times} time
#'   \item \code{Latitude} interpolated latitude of the hurricane at the time
#'   \item \code{Longitude} interpolated longitude of the hurricane at the time
#'   \item \code{Maximum_sustained_wind_speed} interpolated maximum sustained wind
#'   speed at the time
#' }
#' @examples
#' interpolated <- interpolating(data = hurdat, hurricane = 'AL112017')
#' print(interpolated)
#' @export


interpolating <- function(data = dat, hurricane ) {
  hurricane_list = subset(data, id == hurricane)
  time_list = strptime(paste(hurricane_list$date, hurricane_list$time), "%Y%m%d %H%M")
  times = seq(from = min(time_list), to = max(time_list), by = "30 min")
  times = as.POSIXct(times)
  Latitude = approx(time_list, hurricane_list$lat, xout = times)$y
  Longitude = approx(time_list, hurricane_list$long, xout = times)$y
  Maximum_sustained_wind_speed = stats::approx(time_list, hurricane_list$Maximum_sustained_wind_speed, xout = times)$y
  interpolated_track <- data.frame(times, Latitude = Latitude, Longitude = Longitude, Maximum_sustained_wind_speed= Maximum_sustained_wind_speed)


  return(interpolated_track)
}
