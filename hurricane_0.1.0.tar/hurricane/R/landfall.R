#' Determining whether the storm made landfall in the continental United States
#'
#' Given a data and the unique ID of a hurricane, return whether a hurricane
#' made a landfall in the continental US.
#' @param data processed data containing hurricane information
#' @param hurricane unique id of the hurricane to be interpolated
#' @return a boolean value whether hurricane made a landfall in the continental
#' United States
#' @examples
#' whether_landfall <- storm_made_landfall(data = hurdat, hurricane = 'AL112017')
#' print(whether_landfall)
#' @export


storm_made_landfall <- function(data, hurricane) {
  states <-ggplot2::map_data(map = "state")
  hurricane_list = subset(data, id == hurricane)
  continental_us <- states[!(states$region %in% c("Alaska", "Hawaii")), ]

  storm_lat <- hurricane_list$lat
  storm_long <- hurricane_list$long
  storm_in_us <- sp::point.in.polygon(storm_long, storm_lat, continental_us$long, continental_us$lat)

  if (sum(storm_in_us) > 0) {
    return(TRUE)
  } else {
    return(FALSE)
  }
}
