
test_that( "ACE energy looks ok", {

    data(hurdat)
    info <- ACE_calc(data = hurdat, 'AL112017')
    expect_equal(
        info,
        64.8925
    )

})

