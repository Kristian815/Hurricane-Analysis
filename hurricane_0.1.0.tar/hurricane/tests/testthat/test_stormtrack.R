
test_that( "stormtrack looks ok", {

    data(hurdat)
    info <- plot_storm_track(hurdat, 'AL112017')
    expect_equal(
        typeof(info),
        "list"
    )

})

