
test_that( "landfall looks ok", {

    data(hurdat)
    info <- storm_made_landfall(hurdat, 'AL112017')
    expect_equal(
        info,
        TRUE
    )

})

