
test_that( "interpolating looks ok", {

    data(hurdat)
    info <- interpolating(hurdat, 'AL112017')
    expect_equal(
        names(info),
        c("times", "Latitude", "Longitude", "Maximum_sustained_wind_speed")
    )

})

