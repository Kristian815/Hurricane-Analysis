
test_that( "plotstorm looks ok", {

    data(hurdat)
    row <- subset(hurdat, id == 'AL172022')[14,]
    info <- plot_storm(row)
    expect_equal(
        typeof(info),
        "list"
    )

})

