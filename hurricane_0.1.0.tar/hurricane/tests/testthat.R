library(testthat)
library(hurricane)

test_check("hurricane")

